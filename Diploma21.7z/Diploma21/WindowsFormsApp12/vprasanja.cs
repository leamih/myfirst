﻿namespace WindowsFormsApp12
{
}

namespace WindowsFormsApp12 {
    
    
    public partial class vprasanja {
    }
}
