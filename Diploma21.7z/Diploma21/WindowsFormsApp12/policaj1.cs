﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp12
{
    public partial class policaj1 : Form
    {
        public policaj1()
        {
            InitializeComponent();
        }

        private void policaj1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'testloginDataSet.Policist' table. You can move, or remove it, as needed.
            this.policistTableAdapter.Fill(this.testloginDataSet.Policist);

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
            menu mm = new menu();
            mm.Show();
        }
    }
}
