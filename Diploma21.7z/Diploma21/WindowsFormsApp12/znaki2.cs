﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp12
{
    public partial class znaki2 : Form
    {
        public znaki2()
        {
            InitializeComponent();
        }

        private void znaki2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'testloginDataSet1.Znaki' table. You can move, or remove it, as needed.
            this.znakiTableAdapter.Fill(this.testloginDataSet1.Znaki);

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
            menu mm = new menu();
            mm.Show();
        }
    }
}
