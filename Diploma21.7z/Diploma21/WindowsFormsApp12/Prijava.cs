﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp12
{
    public partial class Prijava : Form
    {
        public Prijava()
        {
            InitializeComponent();
            skrijGeslo();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mihael\Documents\testlogin.mdf;Integrated Security=True;Connect Timeout=30");

            SqlDataAdapter sda = new SqlDataAdapter("select count(*) from Uporabnik where 	uporabnik='" + textBox1.Text + "' and geslo='" + textBox2.Text + "'", con);

            DataTable data = new DataTable();
            sda.Fill(data);

            if (data.Rows[0][0].ToString() == "1")
            {
                this.Hide();
                menu f1 = new menu();
                f1.Show();
            }
            else
            {
                MessageBox.Show("Preverite uporabniško ime in geslo!");
            }
        }

      

        public void skrijGeslo()
        {
            textBox2.PasswordChar = '*';
            textBox2.MaxLength = 20;
        }

        private void label3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            registracija rr = new registracija();
            rr.Show();

        }


    }
}
