﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp12
{
    public partial class kviz : Form
    {
        static int index = 0;
        struct vprasanje { public string vpr; }
        struct odgovor { public string o1, o2, o3; }//o1=odgovor1... 
        string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mihael\source\repos\Diploma21\WindowsFormsApp12\testlogin.mdf;Integrated Security=True;Connect Timeout=30";

        public kviz()
        {
            InitializeComponent();
            GenerateQuestionsOptions(index);
        }

        public void GenerateQuestionsOptions(int index)
        {
            // Question based on Index
            vprasanje vpr = new vprasanje();
            vpr.vpr = PopulateQuestions().Rows[index]["vprasanje"].ToString();

            // Options based on Question
            odgovor odg = new odgovor();
            odg.o1 = PopulateQuestions().Rows[index]["odgovor1"].ToString();
            odg.o2 = PopulateQuestions().Rows[index]["odgovor2"].ToString();
            odg.o3 = PopulateQuestions().Rows[index]["odgovor3"].ToString();



            // Adding options to List for shuffling options
            List<string> optionsList = new List<string>();
            optionsList.Add(odg.o1);
            optionsList.Add(odg.o2);
            optionsList.Add(odg.o3);

            // Shuffle options List
            List<string> shuffledOptions = optionsList.OrderBy(a => Guid.NewGuid()).ToList();

            // Assigning question and options
            label1.Text = (index + 1) + " : " + vpr.vpr.ToUpper();
            radioButton1.Text = shuffledOptions[0];
            radioButton2.Text = shuffledOptions[1];
            radioButton3.Text = shuffledOptions[2];



        }

        // Get question and options from database
        private DataTable PopulateQuestions()
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT vprasanje, odgovor1, odgovor2, odgovor3, pravilno FROM Vprasanja", con))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        con.Open();
                        da.Fill(dt);
                        con.Close();
                    }
                }
            }
            return dt;
        }

        private void btnPrevious_Click_1(object sender, EventArgs e)
        {
            if (index > 0)
            {
                index--;
                GenerateQuestionsOptions(index);
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (index < PopulateQuestions().Rows.Count - 1)
            {
                index++;
                GenerateQuestionsOptions(index);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {


            if (radioButton3.Checked)
            {
                MessageBox.Show("Odgovor je pravilen. :D");

            }
            else
            {
                MessageBox.Show("Poskusi znova. :D");

            }
            radioUncheck();

        }

        private void radioUncheck()//"odcekira radiobutton"
        {
            if (radioButton1.Checked || radioButton2.Checked || radioButton3.Checked)
            {
                radioButton1.Checked = false;
                radioButton2.Checked = false;
                radioButton3.Checked = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            

        }

        private void kviz_Load(object sender, EventArgs e)
        {


        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
            menu mm = new menu();
            mm.Show();
        }

        
        }
    }


    
