﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp12
{
    public partial class registracija : Form
    {
        public registracija()
        {
            InitializeComponent();
        }

        string spol;
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Mihael\source\repos\Diploma21\WindowsFormsApp12\testlogin.mdf;Integrated Security=True;Connect Timeout=30");

        private void button1_Click(object sender, EventArgs e)
        {
            preveriSpol();

            if (textBox2.Text== String.Empty || textBox3.Text == String.Empty || textBox1.Text == String.Empty)
            {
                MessageBox.Show("Izpolnite sva obvezna polja");
            }

            if (textBox2.Text != textBox3.Text)
            {
                MessageBox.Show("Gesli se ne ujemata");
            }

            if (textBox2.Text == textBox3.Text)
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Insert into Uporabnik( uporabnik, geslo, naslov,spol) VALUES(@uporabnik, @geslo, @naslov, '" + spol + "')", con);


                cmd.Parameters.AddWithValue("@uporabnik", textBox1.Text.Trim());
                cmd.Parameters.AddWithValue("@geslo", textBox2.Text.Trim());
                cmd.Parameters.AddWithValue("@naslov", richTextBox1.Text.Trim());

                cmd.ExecuteNonQuery();

                MessageBox.Show("Uspela registracija");

                con.Close();
            }

            pocistiPolja();
         

        }

        private void preveriSpol()
        {
            if(radioButton1.Checked == true)
            {
                spol = "moski";
            }

            if (radioButton2.Checked == true)
            {
                spol = "zenski";
            }

        }

        private void pocistiPolja()
        {
            textBox3.Text = String.Empty;
            textBox2.Text = String.Empty;
            textBox1.Text = String.Empty;
            richTextBox1.Text = String.Empty;
        }

        private void label6_Click(object sender, EventArgs e)
        {
            this.Close();
            Prijava prijava = new Prijava();
            prijava.Show();
        }
    }
}
