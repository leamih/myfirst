﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp12
{
    public partial class policaj2 : Form
    {
        public policaj2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            policaj1 p1 = new policaj1();
            p1.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
            menu m = new menu();
            m.Show();
        }
    }
}
