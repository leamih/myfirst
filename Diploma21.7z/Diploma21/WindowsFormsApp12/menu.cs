﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp12
{
    public partial class menu : Form
    {
        public menu()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            policaj2 p2 = new policaj2();
            p2.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
            Prijava pp = new Prijava();
            pp.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            znaki1 z1 = new znaki1();
            z1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            kviz vprasanja = new kviz();
            vprasanja.Show();

        }
    }
}
